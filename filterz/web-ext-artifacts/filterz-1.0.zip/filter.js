'use strict';

document.addEventListener("DOMContentLoaded", function () {
  const properties = { grayscale: undefined, blur: undefined, contrast: undefined, brightness: undefined, hueRotate: undefined, invert: undefined, opacity: undefined, saturate: undefined, sepia: undefined, enabled: undefined }

  async function getFilters() {
    return Promise.all(Object.keys(properties).map(filter => browser.storage.local.get(filter)));
  }

  function applyFilters(values) {
    values.map((value) => properties[Object.keys(value)[0]] = Object.values(value)[0]);
    if (properties.enabled) {
      document.body.style.filter = `grayscale(${properties.grayscale}%) blur(${properties.blur}px) contrast(${properties.contrast}) brightness(${properties.brightness}) hue-rotate(${properties.hueRotate}deg) invert(${properties.invert}) opacity(${properties.opacity}) saturate(${properties.saturate}) sepia(${properties.sepia})`;
    } else {
      document.body.style.filter = '';
    }
  }

  getFilters()
    .then(applyFilters);
  browser.runtime.onMessage.addListener(
    function (request) {
      if (request.message === "apply") {
        getFilters()
          .then(applyFilters);
      }
    }
  );
})

